#ifndef STRING_SET_HPP
#define STRING_SET_HPP

#include <string>
#include <sstream>
#include "DynamicList.hpp"

class StringSet {
private:
    DynamicList<std::string> elements;

    static std::string trim(const std::string& s) {
        int left = 0;
        int right = static_cast<int>(s.size()) - 1;
        while (left <= right && (s[left] == ' ' || s[left] == '\t' || s[left] == '\r' || s[left] == '\n')) ++left;
        while (right >= left && (s[right] == ' ' || s[right] == '\t' || s[right] == '\r' || s[right] == '\n')) --right;
        return s.substr(left, right - left + 1);
    }

public:
    StringSet() = default;

    int size() const {
        return elements.size();
    }

    bool empty() const {
        return elements.empty();
    }

    const std::string& get(int index) const {
        return elements[index];
    }

    bool contains(const std::string& value) const {
        std::string v = trim(value);
        for (int i = 0; i < elements.size(); ++i) {
            if (elements[i] == v) return true;
        }
        return false;
    }

    bool insert(const std::string& value) {
        std::string v = trim(value);
        if (v.empty() || contains(v)) return false;
        elements.pushBack(v);
        return true;
    }

    bool remove(const std::string& value) {
        std::string v = trim(value);
        for (int i = 0; i < elements.size(); ++i) {
            if (elements[i] == v) {
                return elements.removeAt(i);
            }
        }
        return false;
    }

    StringSet setUnion(const StringSet& other) const {
        // TODO-3：实现集合并集 A ∪ B。
        // 提示：先把当前集合元素加入 result，再把 other 中不存在于 result 的元素加入 result。
        StringSet result;
        for (int i = 0; i < elements.size(); ++i) {
            result.insert(elements[i]);
        }
        for (int i = 0; i < other.elements.size(); ++i) {
            result.insert(other.elements[i]);
        }
        return result;
    }

    StringSet intersection(const StringSet& other) const {
        // TODO-4：实现集合交集 A ∩ B。
        // 提示：遍历当前集合，若元素也存在于 other，则加入 result。
        StringSet result;
        for (int i = 0; i < elements.size(); ++i) {
            if (other.contains(elements[i])) {
                result.insert(elements[i]);
            }
        }
        return result;
    }

    StringSet difference(const StringSet& other) const {
        // TODO-5：实现集合差集 A - B。
        // 提示：遍历当前集合，若元素不存在于 other，则加入 result。
        StringSet result;
        for (int i = 0; i < elements.size(); ++i) {
            if (!other.contains(elements[i])) {
                result.insert(elements[i]);
            }
        }
        return result;
    }

    double jaccard(const StringSet& other) const {
        // TODO-6：计算 Jaccard 相似度。
        // 公式：|A ∩ B| / |A ∪ B|。
        // 当并集为空时，返回 0.0。
        StringSet unionSet = setUnion(other);
        if (unionSet.empty()) return 0.0;
        StringSet intersectionSet = intersection(other);
        return static_cast<double>(intersectionSet.size()) / unionSet.size();
    }

    std::string toString(const std::string& sep = ",") const {
        std::ostringstream oss;
        for (int i = 0; i < elements.size(); ++i) {
            if (i > 0) oss << sep;
            oss << elements[i];
        }
        return oss.str();
    }

    static StringSet fromCommaList(const std::string& text) {
        StringSet result;
        std::stringstream ss(text);
        std::string item;
        while (std::getline(ss, item, ',')) {
            result.insert(item);
        }
        return result;
    }
};

#endif
