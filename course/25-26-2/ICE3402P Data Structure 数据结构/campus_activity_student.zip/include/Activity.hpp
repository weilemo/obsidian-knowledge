#ifndef ACTIVITY_HPP
#define ACTIVITY_HPP

#include <string>
#include <sstream>
#include <iomanip>
#include "StringSet.hpp"

inline int parseTimeToMinutes(const std::string& timeText) {
    // 输入格式：HH:MM
    int hour = 0;
    int minute = 0;
    char colon = ':';
    std::stringstream ss(timeText);
    ss >> hour >> colon >> minute;
    return hour * 60 + minute;
}

inline std::string minutesToTime(int minutes) {
    std::ostringstream oss;
    oss << std::setw(2) << std::setfill('0') << (minutes / 60)
        << ":"
        << std::setw(2) << std::setfill('0') << (minutes % 60);
    return oss.str();
}

struct Activity {
    std::string id;
    std::string name;
    std::string categoryPath;
    std::string location;
    int day = 0;
    int startMin = 0;
    int endMin = 0;
    StringSet tags;

    bool conflictsWith(const Activity& other) const {
        if (day != other.day) return false;
        return !(endMin <= other.startMin || other.endMin <= startMin);
    }

    std::string timeText() const {
        std::ostringstream oss;
        oss << "第" << day << "天 " << minutesToTime(startMin) << "-" << minutesToTime(endMin);
        return oss.str();
    }
};

struct Student {
    std::string id;
    std::string name;
    StringSet interests;
};

struct Recommendation {
    Activity activity;
    double score = 0.0;
};

#endif
