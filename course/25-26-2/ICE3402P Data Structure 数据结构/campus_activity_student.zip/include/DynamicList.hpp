#ifndef DYNAMIC_LIST_HPP
#define DYNAMIC_LIST_HPP

#include <stdexcept>

// 学生版：动态顺序表。
// TODO 重点：removeAt、sort。insert 和 pushBack 已给出，便于其他模块先运行。
template <typename T>
class DynamicList {
private:
    T* data;
    int length;
    int capacity;

    void ensureCapacity(int needed) {
        if (needed <= capacity) return;
        int newCapacity = capacity == 0 ? 4 : capacity * 2;
        while (newCapacity < needed) newCapacity *= 2;

        T* newData = new T[newCapacity];
        for (int i = 0; i < length; ++i) {
            newData[i] = data[i];
        }
        delete[] data;
        data = newData;
        capacity = newCapacity;
    }

public:
    DynamicList(int initialCapacity = 4)
        : data(nullptr), length(0), capacity(0) {
        if (initialCapacity < 1) initialCapacity = 4;
        ensureCapacity(initialCapacity);
    }

    DynamicList(const DynamicList& other)
        : data(nullptr), length(0), capacity(0) {
        ensureCapacity(other.capacity);
        length = other.length;
        for (int i = 0; i < length; ++i) {
            data[i] = other.data[i];
        }
    }

    DynamicList& operator=(const DynamicList& other) {
        if (this == &other) return *this;
        T* newData = new T[other.capacity > 0 ? other.capacity : 4];
        for (int i = 0; i < other.length; ++i) {
            newData[i] = other.data[i];
        }
        delete[] data;
        data = newData;
        length = other.length;
        capacity = other.capacity > 0 ? other.capacity : 4;
        return *this;
    }

    ~DynamicList() {
        delete[] data;
    }

    int size() const {
        return length;
    }

    bool empty() const {
        return length == 0;
    }

    void clear() {
        length = 0;
    }

    bool insert(int index, const T& value) {
        if (index < 0 || index > length) return false;
        ensureCapacity(length + 1);
        for (int i = length; i > index; --i) {
            data[i] = data[i - 1];
        }
        data[index] = value;
        ++length;
        return true;
    }

    void pushBack(const T& value) {
        insert(length, value);
    }

    bool removeAt(int index) {
        // TODO-1：删除顺序表中下标为 index 的元素。
        // 要求：
        // 1. index 非法时返回 false；
        // 2. 删除成功时，将 index 后面的元素整体前移一位；
        // 3. length 减 1，并返回 true。
        if (index < 0 || index >= length) return false;
        for (int i = index; i < length - 1; ++i) {
            data[i] = data[i + 1];
        }
        --length;
        return true;
    }

    T& operator[](int index) {
        if (index < 0 || index >= length) {
            throw std::out_of_range("DynamicList index out of range");
        }
        return data[index];
    }

    const T& operator[](int index) const {
        if (index < 0 || index >= length) {
            throw std::out_of_range("DynamicList index out of range");
        }
        return data[index];
    }

    template <typename Predicate>
    int findIndex(Predicate pred) const {
        for (int i = 0; i < length; ++i) {
            if (pred(data[i])) return i;
        }
        return -1;
    }

    template <typename Less>
    void sort(Less less) {
        // TODO-2：实现一个排序算法。
        // 可以使用选择排序、插入排序或冒泡排序。
        // less(a, b) 为 true 表示 a 应排在 b 前面。
        for (int i = 1; i < length; ++i) {
            T current = data[i];
            int j = i - 1;
            while (j >= 0 && less(current, data[j])) {
                data[j + 1] = data[j];
                --j;
            }
            data[j + 1] = current;
        }
    }
};

#endif
