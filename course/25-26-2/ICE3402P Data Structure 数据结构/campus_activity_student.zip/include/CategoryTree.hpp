#ifndef CATEGORY_TREE_HPP
#define CATEGORY_TREE_HPP

#include <iostream>
#include <sstream>
#include <string>
#include "Activity.hpp"
#include "DynamicList.hpp"

class CategoryTree {
private:
    struct Node {
        std::string name;
        int parent = -1;
        DynamicList<int> children;
    };

    DynamicList<Node> nodes;
    int rootIndex = -1;

    static std::string trim(const std::string& s) {
        int left = 0;
        int right = static_cast<int>(s.size()) - 1;
        while (left <= right && (s[left] == ' ' || s[left] == '\t' || s[left] == '\r' || s[left] == '\n')) ++left;
        while (right >= left && (s[right] == ' ' || s[right] == '\t' || s[right] == '\r' || s[right] == '\n')) --right;
        return s.substr(left, right - left + 1);
    }

    bool pathContainsCategory(const std::string& categoryPath, const std::string& categoryName) const {
        std::stringstream ss(categoryPath);
        std::string part;
        while (std::getline(ss, part, '/')) {
            if (trim(part) == categoryName) return true;
        }
        return false;
    }

    void printRecursive(int index, int depth) const {
        if (index < 0 || index >= nodes.size()) return;
        for (int i = 0; i < depth; ++i) std::cout << "  ";
        std::cout << (depth == 0 ? "" : "|- ") << nodes[index].name << "\n";
        for (int i = 0; i < nodes[index].children.size(); ++i) {
            printRecursive(nodes[index].children[i], depth + 1);
        }
    }

public:
    int size() const {
        return nodes.size();
    }

    int findNode(const std::string& name) const {
        for (int i = 0; i < nodes.size(); ++i) {
            if (nodes[i].name == name) return i;
        }
        return -1;
    }

    int addNode(const std::string& name) {
        int existing = findNode(name);
        if (existing != -1) return existing;
        Node node;
        node.name = name;
        nodes.pushBack(node);
        if (rootIndex == -1) rootIndex = nodes.size() - 1;
        return nodes.size() - 1;
    }

    void addEdge(const std::string& parentName, const std::string& childName) {
        int parent = addNode(parentName);
        int child = addNode(childName);
        nodes[child].parent = parent;

        bool already = false;
        for (int i = 0; i < nodes[parent].children.size(); ++i) {
            if (nodes[parent].children[i] == child) already = true;
        }
        if (!already) nodes[parent].children.pushBack(child);
    }

    void print() const {
        if (rootIndex == -1) {
            std::cout << "分类树为空\n";
            return;
        }
        printRecursive(rootIndex, 0);
    }

    std::string pathToRoot(const std::string& categoryName) const {
        // TODO-7：给定类别名称，输出从根结点到该类别的路径。
        // 例如：校园活动 -> 学术类 -> 计算机
        // 提示：先 findNode 找到类别下标，再不断沿 parent 回溯到根；
        // 为了顺序正确，可以使用 DynamicList 的头插 insert(0, value)。
        int current = findNode(trim(categoryName));
        if (current == -1) return "未找到该类别";

        DynamicList<std::string> path;
        while (current != -1) {
            path.insert(0, nodes[current].name);
            current = nodes[current].parent;
        }

        std::ostringstream oss;
        for (int i = 0; i < path.size(); ++i) {
            if (i > 0) oss << " -> ";
            oss << path[i];
        }
        return oss.str();
    }

    int countActivities(const std::string& categoryName, const DynamicList<Activity>& activities) const {
        // TODO-8：统计某类别及其子类别下的活动数量。
        // 本项目的数据中，活动分类路径形如：校园活动/学术类/计算机。
        // 因此可以判断 categoryName 是否出现在 activity.categoryPath 的路径片段中。
        // 提示：可以使用上面的 pathContainsCategory 辅助函数。
        std::string target = trim(categoryName);
        if (findNode(target) == -1) return 0;

        int count = 0;
        for (int i = 0; i < activities.size(); ++i) {
            if (pathContainsCategory(activities[i].categoryPath, target)) {
                ++count;
            }
        }
        return count;
    }
};

#endif
