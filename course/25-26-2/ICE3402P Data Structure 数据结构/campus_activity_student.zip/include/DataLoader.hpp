#ifndef DATA_LOADER_HPP
#define DATA_LOADER_HPP

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include "Activity.hpp"
#include "CategoryTree.hpp"
#include "Graph.hpp"

namespace DataLoader {

inline std::string trim(const std::string& s) {
    int left = 0;
    int right = static_cast<int>(s.size()) - 1;
    while (left <= right && (s[left] == ' ' || s[left] == '\t' || s[left] == '\r' || s[left] == '\n')) ++left;
    while (right >= left && (s[right] == ' ' || s[right] == '\t' || s[right] == '\r' || s[right] == '\n')) --right;
    return s.substr(left, right - left + 1);
}

inline DynamicList<std::string> split(const std::string& text, char delimiter) {
    DynamicList<std::string> result;
    std::stringstream ss(text);
    std::string item;
    while (std::getline(ss, item, delimiter)) {
        result.pushBack(trim(item));
    }
    return result;
}

inline bool loadCategories(const std::string& filename, CategoryTree& tree) {
    std::ifstream in(filename);
    if (!in) {
        std::cerr << "无法打开分类文件：" << filename << "\n";
        return false;
    }

    std::string line;
    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;
        DynamicList<std::string> fields = split(line, '|');
        if (fields.size() >= 2) {
            tree.addEdge(fields[0], fields[1]);
        }
    }
    return true;
}

inline bool loadLocations(const std::string& filename, Graph& graph) {
    std::ifstream in(filename);
    if (!in) {
        std::cerr << "无法打开地点文件：" << filename << "\n";
        return false;
    }

    std::string line;
    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;
        graph.addVertex(line);
    }
    return true;
}

inline bool loadRoads(const std::string& filename, Graph& graph) {
    std::ifstream in(filename);
    if (!in) {
        std::cerr << "无法打开道路文件：" << filename << "\n";
        return false;
    }

    std::string line;
    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;
        DynamicList<std::string> fields = split(line, '|');
        if (fields.size() >= 3) {
            graph.addEdge(fields[0], fields[1], std::stoi(fields[2]));
        }
    }
    return true;
}

inline bool loadActivities(const std::string& filename, DynamicList<Activity>& activities) {
    std::ifstream in(filename);
    if (!in) {
        std::cerr << "无法打开活动文件：" << filename << "\n";
        return false;
    }

    std::string line;
    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;
        DynamicList<std::string> fields = split(line, '|');
        if (fields.size() >= 8) {
            Activity activity;
            activity.id = fields[0];
            activity.name = fields[1];
            activity.categoryPath = fields[2];
            activity.location = fields[3];
            activity.day = std::stoi(fields[4]);
            activity.startMin = parseTimeToMinutes(fields[5]);
            activity.endMin = parseTimeToMinutes(fields[6]);
            activity.tags = StringSet::fromCommaList(fields[7]);
            activities.pushBack(activity);
        }
    }
    return true;
}

inline bool loadStudents(const std::string& filename, DynamicList<Student>& students) {
    std::ifstream in(filename);
    if (!in) {
        std::cerr << "无法打开学生文件：" << filename << "\n";
        return false;
    }

    std::string line;
    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;
        DynamicList<std::string> fields = split(line, '|');
        if (fields.size() >= 3) {
            Student student;
            student.id = fields[0];
            student.name = fields[1];
            student.interests = StringSet::fromCommaList(fields[2]);
            students.pushBack(student);
        }
    }
    return true;
}

} // namespace DataLoader

#endif
