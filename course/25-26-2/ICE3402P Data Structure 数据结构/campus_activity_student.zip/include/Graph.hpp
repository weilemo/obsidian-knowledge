#ifndef GRAPH_HPP
#define GRAPH_HPP

#include <iostream>
#include <sstream>
#include <string>
#include "DynamicList.hpp"

struct PathResult {
    bool reachable = false;
    int distance = 0;
    DynamicList<std::string> nodes;

    std::string toString() const {
        if (!reachable) return "不可达";
        std::ostringstream oss;
        oss << "距离/时间：" << distance << " 分钟，路径：";
        for (int i = 0; i < nodes.size(); ++i) {
            if (i > 0) oss << " -> ";
            oss << nodes[i];
        }
        return oss.str();
    }
};

class Graph {
private:
    static const int INF = 1000000000;
    int maxVertices;
    DynamicList<std::string> vertices;
    int** weight;

public:
    Graph(int maxV = 200)
        : maxVertices(maxV), vertices(maxV) {
        weight = new int*[maxVertices];
        for (int i = 0; i < maxVertices; ++i) {
            weight[i] = new int[maxVertices];
            for (int j = 0; j < maxVertices; ++j) {
                weight[i][j] = (i == j ? 0 : INF);
            }
        }
    }

    Graph(const Graph&) = delete;
    Graph& operator=(const Graph&) = delete;

    ~Graph() {
        for (int i = 0; i < maxVertices; ++i) {
            delete[] weight[i];
        }
        delete[] weight;
    }

    int vertexCount() const {
        return vertices.size();
    }

    int edgeCount() const {
        int count = 0;
        for (int i = 0; i < vertices.size(); ++i) {
            for (int j = i + 1; j < vertices.size(); ++j) {
                if (weight[i][j] < INF) ++count;
            }
        }
        return count;
    }

    int indexOf(const std::string& name) const {
        for (int i = 0; i < vertices.size(); ++i) {
            if (vertices[i] == name) return i;
        }
        return -1;
    }

    int addVertex(const std::string& name) {
        int existing = indexOf(name);
        if (existing != -1) return existing;
        if (vertices.size() >= maxVertices) return -1;
        vertices.pushBack(name);
        return vertices.size() - 1;
    }

    void addEdge(const std::string& a, const std::string& b, int w) {
        int ia = addVertex(a);
        int ib = addVertex(b);
        if (ia == -1 || ib == -1) return;
        if (w < weight[ia][ib]) {
            weight[ia][ib] = w;
            weight[ib][ia] = w;
        }
    }

    void printAdjacencyMatrix() const {
        std::cout << "地点数：" << vertices.size() << "，道路数：" << edgeCount() << "\n";
        for (int i = 0; i < vertices.size(); ++i) {
            std::cout << vertices[i] << ": ";
            bool first = true;
            for (int j = 0; j < vertices.size(); ++j) {
                if (i != j && weight[i][j] < INF) {
                    if (!first) std::cout << ", ";
                    std::cout << vertices[j] << "(" << weight[i][j] << ")";
                    first = false;
                }
            }
            std::cout << "\n";
        }
    }

    DynamicList<std::string> bfsOrder(const std::string& startName) const {
        // TODO-9：实现图的 BFS 遍历。
        // 要求：
        // 1. 根据 startName 找到起点下标；
        // 2. 使用 visited 数组记录是否访问；
        // 3. 使用数组模拟队列；
        // 4. 返回访问到的地点名称顺序。
        DynamicList<std::string> order;
        int start = indexOf(startName);
        if (start == -1) return order;

        int n = vertices.size();
        bool* visited = new bool[n];
        int* queue = new int[n];
        for (int i = 0; i < n; ++i) {
            visited[i] = false;
        }

        int front = 0;
        int rear = 0;
        visited[start] = true;
        queue[rear++] = start;

        while (front < rear) {
            int current = queue[front++];
            order.pushBack(vertices[current]);

            for (int next = 0; next < n; ++next) {
                if (!visited[next] && weight[current][next] < INF) {
                    visited[next] = true;
                    queue[rear++] = next;
                }
            }
        }

        delete[] visited;
        delete[] queue;
        return order;
    }

    bool isConnected(const std::string& a, const std::string& b) const {
        DynamicList<std::string> order = bfsOrder(a);
        for (int i = 0; i < order.size(); ++i) {
            if (order[i] == b) return true;
        }
        return false;
    }

    PathResult shortestPath(const std::string& startName, const std::string& endName) const {
        // TODO-10：实现 Dijkstra 最短路径。
        // 要求：
        // 1. dist[i] 表示起点到 i 的当前最短距离；
        // 2. prev[i] 记录最短路径上 i 的前驱结点；
        // 3. 每轮选择未访问且 dist 最小的顶点 u；
        // 4. 用 u 松弛其相邻边；
        // 5. 最后根据 prev 数组还原路径，写入 PathResult.nodes。
        PathResult result;
        int start = indexOf(startName);
        int target = indexOf(endName);
        if (start == -1 || target == -1) return result;

        int n = vertices.size();
        bool* visited = new bool[n];
        int* dist = new int[n];
        int* prev = new int[n];
        for (int i = 0; i < n; ++i) {
            visited[i] = false;
            dist[i] = INF;
            prev[i] = -1;
        }
        dist[start] = 0;

        for (int step = 0; step < n; ++step) {
            int current = -1;
            int best = INF;
            for (int i = 0; i < n; ++i) {
                if (!visited[i] && dist[i] < best) {
                    best = dist[i];
                    current = i;
                }
            }

            if (current == -1) break;
            visited[current] = true;
            if (current == target) break;

            for (int next = 0; next < n; ++next) {
                if (!visited[next] && weight[current][next] < INF) {
                    int candidate = dist[current] + weight[current][next];
                    if (candidate < dist[next]) {
                        dist[next] = candidate;
                        prev[next] = current;
                    }
                }
            }
        }

        if (dist[target] < INF) {
            result.reachable = true;
            result.distance = dist[target];
            for (int current = target; current != -1; current = prev[current]) {
                result.nodes.insert(0, vertices[current]);
            }
        }

        delete[] visited;
        delete[] dist;
        delete[] prev;
        return result;
    }
};

#endif
