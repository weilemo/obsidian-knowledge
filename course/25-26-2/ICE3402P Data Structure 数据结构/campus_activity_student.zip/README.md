# 校园活动导航与个性化推荐系统：学生版工程

本压缩包是数据结构课程大作业的学生版工程，已去除完整参考答案，只保留工程骨架、菜单程序、数据加载逻辑、测试数据和待补全代码。

## 你需要完成什么

请补全源码中标记为 `TODO-1` 到 `TODO-10` 的核心代码。它们覆盖线性表、集合、树和图四类数据结构。

| TODO | 文件 | 内容 | 对应数据结构 |
|---|---|---|---|
| TODO-1 | `include/DynamicList.hpp` | 顺序表按下标删除 | 线性表 |
| TODO-2 | `include/DynamicList.hpp` | 顺序表排序 | 线性表 |
| TODO-3 | `include/StringSet.hpp` | 集合并集 | 集合 |
| TODO-4 | `include/StringSet.hpp` | 集合交集 | 集合 |
| TODO-5 | `include/StringSet.hpp` | 集合差集 | 集合 |
| TODO-6 | `include/StringSet.hpp` | Jaccard 相似度 | 集合 |
| TODO-7 | `include/CategoryTree.hpp` | 分类树根到类别路径 | 树 |
| TODO-8 | `include/CategoryTree.hpp` | 某类别下活动数量统计 | 树 |
| TODO-9 | `include/Graph.hpp` | BFS 遍历 | 图 |
| TODO-10 | `include/Graph.hpp` | Dijkstra 最短路径 | 图 |

## 编译运行

在本目录下执行：

```bash
g++ -std=c++17 -Iinclude src/main.cpp -o campus_app
./campus_app data
```

也可以使用 CMake：

```bash
cmake -S . -B build
cmake --build build
./build/campus_app data
```

## 数据文件

`data` 目录下已包含测试数据：

- `activities.txt`：400 条活动。
- `students.txt`：120 名学生兴趣数据。
- `locations.txt`：32 个校园地点。
- `roads.txt`：96 条校园道路。
- `categories.txt`：36 条分类树边。

`tools/generate_data.py` 是测试数据生成脚本，供了解数据格式或重新生成类似数据时使用，不是必须运行的程序。

## 作业说明

请优先阅读 `课程大作业说明书_学生版.docx`，其中包含项目背景、功能要求、评分标准、验收建议和提交要求。
