const data = window.CAMPUS_DATA;
const ALL = "全部";

const state = {
  keyword: "",
  category: ALL,
  location: ALL,
  tag: ALL,
  dayStart: 1,
  dayEnd: 30,
  sort: "time",
  limit: 12,
  studentId: data.students[0]?.id || "",
  schedules: JSON.parse(localStorage.getItem("campusSchedules") || "{}"),
};

const $ = (id) => document.getElementById(id);
const toSet = (items) => new Set((items || []).filter(Boolean));
const duration = (activity) => activity.endMin - activity.startMin;

function saveSchedules() {
  localStorage.setItem("campusSchedules", JSON.stringify(state.schedules));
}

function student() {
  return data.students.find((item) => item.id === state.studentId) || data.students[0];
}

function jaccard(left, right) {
  const a = toSet(left);
  const b = toSet(right);
  const union = new Set([...a, ...b]);
  if (union.size === 0) return 0;
  let same = 0;
  a.forEach((item) => {
    if (b.has(item)) same += 1;
  });
  return same / union.size;
}

function recommendationScore(activity, targetStudent = student()) {
  if (!targetStudent) return 0;
  const interestSet = toSet(targetStudent.interests);
  const tagScore = jaccard(targetStudent.interests, activity.tags);
  const categoryScore = activity.categoryParts.some((part) => interestSet.has(part)) ? 1 : 0;
  const locationScore = targetStudent.interests.some((item) => activity.location.includes(item)) ? 1 : 0;
  const shortActivityBonus = duration(activity) <= 120 ? 0.05 : 0;
  return Math.min(1, tagScore * 0.7 + categoryScore * 0.2 + locationScore * 0.05 + shortActivityBonus);
}

function conflicts(a, b) {
  return a.day === b.day && !(a.endMin <= b.startMin || b.endMin <= a.startMin);
}

function fillSelect(select, values, first = ALL) {
  select.innerHTML = "";
  [first, ...values].forEach((value) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    select.appendChild(option);
  });
}

function initControls() {
  $("activityCount").textContent = data.activities.length;
  $("studentCount").textContent = data.students.length;
  $("locationCount").textContent = data.locations.length;
  $("roadCount").textContent = data.roads.length;

  const categories = [...new Set(data.activities.map((item) => item.primaryCategory))].sort();
  const locations = [...data.locations].sort();
  const tags = [...new Set(data.activities.flatMap((item) => item.tags))].sort();
  fillSelect($("categorySelect"), categories);
  fillSelect($("locationSelect"), locations);
  fillSelect($("tagSelect"), tags);

  $("studentSelect").innerHTML = "";
  data.students.forEach((item) => {
    const option = document.createElement("option");
    option.value = item.id;
    option.textContent = `${item.id} ${item.name}`;
    $("studentSelect").appendChild(option);
  });
  $("studentSelect").value = state.studentId;

  $("applyFilters").addEventListener("click", readControls);
  $("clearFilters").addEventListener("click", clearControls);
  $("limitSelect").addEventListener("change", readControls);
  $("studentSelect").addEventListener("change", readControls);
  $("exportSummary").addEventListener("click", exportSummary);
  $("resetState").addEventListener("click", () => {
    state.schedules = {};
    saveSchedules();
    renderAll();
  });
}

function clampDay(value, fallback) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(30, Math.max(1, Math.round(parsed)));
}

function readControls() {
  state.keyword = $("keywordInput").value.trim();
  state.category = $("categorySelect").value;
  state.location = $("locationSelect").value;
  state.tag = $("tagSelect").value;
  state.dayStart = clampDay($("dayStart").value, 1);
  state.dayEnd = clampDay($("dayEnd").value, 30);
  if (state.dayStart > state.dayEnd) {
    [state.dayStart, state.dayEnd] = [state.dayEnd, state.dayStart];
  }
  $("dayStart").value = state.dayStart;
  $("dayEnd").value = state.dayEnd;
  state.sort = $("sortSelect").value;
  state.limit = Number($("limitSelect").value || 12);
  state.studentId = $("studentSelect").value;
  renderAll();
}

function clearControls() {
  $("keywordInput").value = "";
  $("categorySelect").value = ALL;
  $("locationSelect").value = ALL;
  $("tagSelect").value = ALL;
  $("dayStart").value = 1;
  $("dayEnd").value = 30;
  $("sortSelect").value = "time";
  readControls();
}

function filteredActivities() {
  const key = state.keyword.toLowerCase();
  const result = data.activities.filter((activity) => {
    const haystack = `${activity.id} ${activity.name} ${activity.location} ${activity.categoryPath} ${activity.tags.join(" ")}`.toLowerCase();
    return (
      (!key || haystack.includes(key)) &&
      (state.category === ALL || activity.primaryCategory === state.category) &&
      (state.location === ALL || activity.location === state.location) &&
      (state.tag === ALL || activity.tags.includes(state.tag)) &&
      activity.day >= state.dayStart &&
      activity.day <= state.dayEnd
    );
  });

  result.sort((a, b) => {
    if (state.sort === "recommend") {
      const scoreDiff = recommendationScore(b) - recommendationScore(a);
      if (scoreDiff !== 0) return scoreDiff;
    }
    if (state.sort === "duration") {
      const durationDiff = duration(b) - duration(a);
      if (durationDiff !== 0) return durationDiff;
    }
    return a.day - b.day || a.startMin - b.startMin || a.id.localeCompare(b.id);
  });
  return result;
}

function scheduleIds() {
  return state.schedules[state.studentId] || [];
}

function renderActivities() {
  const list = $("activityList");
  const items = filteredActivities();
  const shown = Math.min(state.limit, items.length);
  $("resultText").innerHTML = `共筛选出 <strong>${items.length}</strong> 条，当前显示前 <strong>${shown}</strong> 条`;
  list.innerHTML = "";

  if (items.length === 0) {
    list.innerHTML = `
      <div class="empty">
        <svg viewBox="0 0 24 24" width="42" height="42" stroke="currentColor" stroke-width="1" fill="none" style="margin-bottom: 12px; color: var(--text-muted); opacity: 0.4;">
          <circle cx="11" cy="11" r="8"></circle>
          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          <line x1="11" y1="8" x2="11" y2="14"></line>
          <line x1="8" y1="11" x2="14" y2="11"></line>
        </svg>
        <div>没有符合条件的活动，请放宽筛选条件。</div>
      </div>
    `;
    return;
  }

  const currentSchedule = new Set(scheduleIds());
  items.slice(0, state.limit).forEach((activity) => {
    const node = $("activityTemplate").content.firstElementChild.cloneNode(true);
    const score = Math.round(recommendationScore(activity) * 100);
    
    node.querySelector(".category").textContent = `${activity.primaryCategory} / ${activity.leafCategory}`;
    node.querySelector("h3").textContent = `${activity.id} ${activity.name}`;
    node.querySelector(".score").innerHTML = `<span style="font-size:10px; margin-right:2px;">匹配度</span>${score}%`;
    
    // 注入带有 SVG 图标的 Meta 信息
    node.querySelector(".meta").innerHTML = `
      <span style="display:flex; align-items:center; gap:4px;">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
        ${activity.location}
      </span>
      <span style="display:flex; align-items:center; gap:4px;">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
        第 ${activity.day} 天
      </span>
      <span style="display:flex; align-items:center; gap:4px;">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
        ${activity.start} - ${activity.end}
      </span>
    `;
    
    node.querySelector(".tags").innerHTML = activity.tags.slice(0, 6).map((tag) => `<span>${tag}</span>`).join("");
    
    const button = node.querySelector(".add-button");
    if (currentSchedule.has(activity.id)) {
      button.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 4px;"><polyline points="20 6 9 17 4 12"></polyline></svg>已加入`;
      button.disabled = true;
      button.classList.add("secondary");
    } else {
      button.addEventListener("click", () => addToSchedule(activity.id));
    }
    list.appendChild(node);
  });
}

function addToSchedule(activityId) {
  const id = state.studentId;
  if (!id) return;
  const current = state.schedules[id] || [];
  if (!current.includes(activityId)) {
    state.schedules[id] = [...current, activityId];
    saveSchedules();
  }
  renderAll();
}

function removeFromSchedule(activityId) {
  const id = state.studentId;
  state.schedules[id] = (state.schedules[id] || []).filter((item) => item !== activityId);
  saveSchedules();
  renderAll();
}

function renderStudentProfile() {
  const current = student();
  if (!current) return;
  $("studentName").textContent = `${current.name} (${current.id})`;
  $("studentInterestTags").innerHTML = current.interests.slice(0, 12).map((tag) => `<span>${tag}</span>`).join("");
  const best = [...data.activities].sort((a, b) => recommendationScore(b, current) - recommendationScore(a, current))[0];
  $("fitHint").innerHTML = best
    ? `当前最高匹配：<strong>${best.name}</strong><br><span style="opacity:0.8; font-size:12px;">推荐度 ${Math.round(recommendationScore(best, current) * 100)}% · 第${best.day}天 · ${best.location}</span>`
    : "暂无可计算的推荐活动。";
}

function renderScheduleTabs() {
  const tabs = $("scheduleTabs");
  tabs.innerHTML = "";
  data.students.slice(0, 6).forEach((item) => {
    const button = document.createElement("button");
    button.textContent = item.id;
    button.className = item.id === state.studentId ? "active" : "";
    button.addEventListener("click", () => {
      state.studentId = item.id;
      $("studentSelect").value = item.id;
      renderAll();
    });
    tabs.appendChild(button);
  });
}

function scheduleConflictPairs(activities) {
  const pairs = [];
  for (let i = 0; i < activities.length; ++i) {
    for (let j = i + 1; j < activities.length; ++j) {
      if (conflicts(activities[i], activities[j])) {
        pairs.push([activities[i], activities[j]]);
      }
    }
  }
  return pairs;
}

function renderSchedule() {
  renderScheduleTabs();
  const list = $("scheduleList");
  const activities = scheduleIds()
    .map((id) => data.activities.find((item) => item.id === id))
    .filter(Boolean)
    .sort((a, b) => a.day - b.day || a.startMin - b.startMin);
  const pairs = scheduleConflictPairs(activities);
  
  $("selectedCount").textContent = activities.length;
  $("conflictCount").textContent = pairs.length;
  list.innerHTML = "";

  if (activities.length === 0) {
    list.innerHTML = `
      <div class="empty">
        <svg viewBox="0 0 24 24" width="36" height="36" stroke="currentColor" stroke-width="1" fill="none" style="margin-bottom: 12px; color: var(--text-muted); opacity: 0.4;">
          <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line>
        </svg>
        <div>当前学生日程为空，请从左侧添加。</div>
      </div>
    `;
    return;
  }

  activities.forEach((activity) => {
    const conflictList = activities.filter((other) => other.id !== activity.id && conflicts(activity, other));
    const row = document.createElement("article");
    row.className = `schedule-item ${conflictList.length ? "conflict" : ""}`;
    
    // 注入更精美的日程卡片 UI
    row.innerHTML = `
      <div class="activity-marker"></div>
      <div style="flex:1; min-width:0;">
        <h3 style="margin:0 0 4px 0; font-size:14px; font-weight:700; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
          ${activity.name}
        </h3>
        <p class="meta" style="font-size:12px; margin:0;">
          第 ${activity.day} 天 ${activity.start}-${activity.end} · ${activity.location}
        </p>
        ${conflictList.length ? `
          <p class="meta" style="margin-top:6px; font-size:11px; background:var(--danger-light); color:var(--danger); display:inline-block; padding:2px 6px; border-radius:4px;">
            <span class="conflict-label">与以下项冲突：</span>${conflictList.map((item) => item.id).join(", ")}
          </p>
        ` : ""}
      </div>
      <button class="secondary" style="min-height:28px; padding:0 10px; font-size:12px;" title="移除">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
      </button>
    `;
    row.querySelector("button").addEventListener("click", () => removeFromSchedule(activity.id));
    list.appendChild(row);
  });
}

function countBy(items, keyFn) {
  const counts = new Map();
  items.forEach((item) => counts.set(keyFn(item), (counts.get(keyFn(item)) || 0) + 1));
  return [...counts.entries()];
}

function drawBarChart(canvas, rows, color) {
  const ctx = canvas.getContext("2d");
  const width = canvas.width;
  const height = canvas.height;
  ctx.clearRect(0, 0, width, height);
  const max = Math.max(...rows.map((row) => row[1]), 1);
  const left = 92;
  const top = 20;
  const gap = 9;
  const barH = Math.max(18, (height - 54) / rows.length - gap);
  rows.forEach(([label, value], index) => {
    const y = top + index * (barH + gap);
    const barW = Math.round(((width - left - 76) * value) / max);
    ctx.fillStyle = "#64748b";
    ctx.font = "500 13px -apple-system, sans-serif";
    ctx.fillText(label, 14, y + barH - 4);
    
    // 绘制轨道底色
    ctx.fillStyle = "rgba(23, 107, 84, 0.06)";
    ctx.beginPath();
    ctx.roundRect(left, y, width - left - 60, barH, 4);
    ctx.fill();
    
    // 绘制数据条
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.roundRect(left, y, barW, barH, 4);
    ctx.fill();
    
    ctx.fillStyle = "#1e293b";
    ctx.font = "bold 13px -apple-system, sans-serif";
    ctx.fillText(String(value), left + barW + 8, y + barH - 4);
  });
}

function drawDayChart(canvas, rows) {
  const ctx = canvas.getContext("2d");
  const width = canvas.width;
  const height = canvas.height;
  ctx.clearRect(0, 0, width, height);
  const max = Math.max(...rows.map((row) => row[1]), 1);
  const chartW = width - 54;
  const chartH = height - 56;
  const barW = chartW / 30 - 2;
  
  ctx.strokeStyle = "rgba(0,0,0,0.06)";
  ctx.beginPath();
  ctx.moveTo(36, 18);
  ctx.lineTo(36, chartH + 18);
  ctx.lineTo(width - 16, chartH + 18);
  ctx.stroke();
  
  rows.forEach(([day, value]) => {
    const x = 38 + (Number(day) - 1) * (barW + 2);
    const h = (chartH * value) / max;
    ctx.fillStyle = value === max ? "#b97923" : "#234c68";
    // 增加一点圆角
    ctx.beginPath();
    ctx.roundRect(x, chartH + 18 - h, Math.max(4, barW), h, [2, 2, 0, 0]);
    ctx.fill();
  });
  
  ctx.fillStyle = "#64748b";
  ctx.font = "12px -apple-system, sans-serif";
  ctx.fillText("1", 36, height - 14);
  ctx.fillText("15", width / 2 - 10, height - 14);
  ctx.fillText("30", width - 32, height - 14);
}

function drawMap(canvas) {
  const ctx = canvas.getContext("2d");
  const width = canvas.width;
  const height = canvas.height;
  ctx.clearRect(0, 0, width, height);
  
  // 绘制更通透的网格
  ctx.strokeStyle = "rgba(0, 0, 0, 0.03)";
  for (let x = 36; x < width; x += 48) {
    ctx.beginPath(); ctx.moveTo(x, 20); ctx.lineTo(x, height - 20); ctx.stroke();
  }
  for (let y = 28; y < height; y += 42) {
    ctx.beginPath(); ctx.moveTo(24, y); ctx.lineTo(width - 24, y); ctx.stroke();
  }

  const centerX = width / 2;
  const centerY = height / 2;
  const radiusX = width * 0.42;
  const radiusY = height * 0.35;
  const pos = new Map();
  data.locations.forEach((name, index) => {
    const angle = (Math.PI * 2 * index) / data.locations.length - Math.PI / 2;
    pos.set(name, {
      x: centerX + Math.cos(angle) * radiusX,
      y: centerY + Math.sin(angle) * radiusY,
    });
  });

  data.roads.forEach((road) => {
    const a = pos.get(road.a);
    const b = pos.get(road.b);
    if (!a || !b) return;
    ctx.strokeStyle = "rgba(35, 76, 104, 0.15)";
    ctx.lineWidth = Math.max(1, 4 - road.weight / 6);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  });

  data.locations.forEach((name, index) => {
    const p = pos.get(name);
    const major = index < 4 || ["图书馆", "大学生活动中心", "体育馆", "校门"].includes(name);
    ctx.fillStyle = major ? "#b97923" : "#176b54";
    ctx.beginPath();
    ctx.arc(p.x, p.y, major ? 5 : 3.5, 0, Math.PI * 2);
    ctx.fill();
    if (major || index % 4 === 0) {
      ctx.fillStyle = "#1e293b";
      ctx.font = "600 12px -apple-system, sans-serif";
      ctx.fillText(name, p.x + 8, p.y + 4);
    }
  });
}

function renderCharts() {
  const categoryRows = countBy(data.activities, (item) => item.primaryCategory)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8);
  drawBarChart($("categoryChart"), categoryRows, "#176b54");

  const dayCounts = new Map(Array.from({ length: 30 }, (_, i) => [String(i + 1), 0]));
  data.activities.forEach((item) => dayCounts.set(String(item.day), (dayCounts.get(String(item.day)) || 0) + 1));
  drawDayChart($("dayChart"), [...dayCounts.entries()]);
  drawMap($("mapCanvas"));
}

function renderAll() {
  renderStudentProfile();
  renderActivities();
  renderSchedule();
  renderCharts();
}

function exportSummary() {
  const currentStudent = student();
  const activities = filteredActivities().slice(0, state.limit);
  const lines = [
    "校园活动导航与个性化推荐系统 - 当前摘要",
    `学生：${currentStudent.id} ${currentStudent.name}`,
    `兴趣：${currentStudent.interests.join("、")}`,
    `筛选结果：${activities.length} 条已显示`,
    "",
    ...activities.map((item) => `${item.id} ${item.name} 第${item.day}天 ${item.start}-${item.end} ${item.location}`),
  ];
  const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "campus_activity_summary.txt";
  link.click();
  URL.revokeObjectURL(link.href);
}

initControls();
renderAll();