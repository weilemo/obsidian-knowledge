#include <iostream>
#include <iomanip>
#include <string>
#include "DataLoader.hpp"

using std::cout;
using std::cin;
using std::string;

bool inputEnded = false;

string readLine(const string& prompt) {
    cout << prompt;
    string value;
    if (!std::getline(cin, value)) {
        inputEnded = true;
        return "";
    }
    return DataLoader::trim(value);
}

bool parseIntStrict(const string& text, int& value) {
    try {
        string::size_type consumed = 0;
        int parsed = std::stoi(text, &consumed);
        if (consumed != text.size()) return false;
        value = parsed;
        return true;
    } catch (...) {
        return false;
    }
}

int parseIntOrDefault(const string& text, int defaultValue) {
    if (text.empty()) return defaultValue;
    int value = defaultValue;
    if (parseIntStrict(text, value)) return value;
    cout << "输入不是有效数字，使用默认值 " << defaultValue << "。\n";
    return defaultValue;
}

int findActivityIndex(const DynamicList<Activity>& activities, const string& id) {
    for (int i = 0; i < activities.size(); ++i) {
        if (activities[i].id == id) return i;
    }
    return -1;
}

int findStudentIndex(const DynamicList<Student>& students, const string& id) {
    for (int i = 0; i < students.size(); ++i) {
        if (students[i].id == id) return i;
    }
    return -1;
}

void printActivityBrief(const Activity& a) {
    cout << std::left << std::setw(7) << a.id
         << std::setw(28) << a.name
         << std::setw(24) << a.categoryPath
         << std::setw(16) << a.location
         << std::setw(18) << a.timeText()
         << "标签{" << a.tags.toString(",") << "}\n";
}

void printActivityDetail(const Activity& a) {
    cout << "活动编号：" << a.id << "\n";
    cout << "活动名称：" << a.name << "\n";
    cout << "分类路径：" << a.categoryPath << "\n";
    cout << "活动地点：" << a.location << "\n";
    cout << "活动时间：" << a.timeText() << "\n";
    cout << "活动标签：" << a.tags.toString(",") << "\n";
}

bool activityLessByTime(const Activity& a, const Activity& b) {
    if (a.day != b.day) return a.day < b.day;
    if (a.startMin != b.startMin) return a.startMin < b.startMin;
    return a.id < b.id;
}

void listActivities(const DynamicList<Activity>& activities) {
    string text = readLine("显示前多少条活动？默认 20：");
    int limit = parseIntOrDefault(text, 20);
    DynamicList<Activity> copy = activities;
    copy.sort(activityLessByTime);
    cout << "\n按时间排序后的活动：\n";
    for (int i = 0; i < copy.size() && i < limit; ++i) {
        printActivityBrief(copy[i]);
    }
}

void findActivity(const DynamicList<Activity>& activities) {
    string id = readLine("请输入活动编号，例如 A0001：");
    int idx = findActivityIndex(activities, id);
    if (idx == -1) {
        cout << "未找到活动：" << id << "\n";
        return;
    }
    printActivityDetail(activities[idx]);
}

void addActivity(DynamicList<Activity>& activities) {
    Activity a;
    a.id = readLine("活动编号：");
    if (a.id.empty()) {
        cout << "编号不能为空。\n";
        return;
    }
    if (findActivityIndex(activities, a.id) != -1) {
        cout << "编号已存在，不能重复添加。\n";
        return;
    }
    a.name = readLine("活动名称：");
    a.categoryPath = readLine("分类路径，例如 校园活动/学术类/计算机：");
    a.location = readLine("地点：");
    int day = 0;
    if (!parseIntStrict(readLine("第几天，1-30："), day)) {
        cout << "日期输入无效，取消添加。\n";
        return;
    }
    a.day = day;
    a.startMin = parseTimeToMinutes(readLine("开始时间 HH:MM："));
    a.endMin = parseTimeToMinutes(readLine("结束时间 HH:MM："));
    a.tags = StringSet::fromCommaList(readLine("标签，用英文逗号分隔："));
    activities.pushBack(a);
    cout << "已添加活动。\n";
}

void deleteActivity(DynamicList<Activity>& activities) {
    string id = readLine("请输入要删除的活动编号：");
    int idx = findActivityIndex(activities, id);
    if (idx == -1) {
        cout << "未找到活动。\n";
        return;
    }
    activities.removeAt(idx);
    cout << "已删除活动：" << id << "\n";
}

void modifyActivity(DynamicList<Activity>& activities) {
    string id = readLine("请输入要修改的活动编号：");
    int idx = findActivityIndex(activities, id);
    if (idx == -1) {
        cout << "未找到活动。\n";
        return;
    }

    Activity& a = activities[idx];
    cout << "当前活动信息：\n";
    printActivityDetail(a);
    cout << "直接回车表示保留原值。\n";

    string value;
    value = readLine("新名称：");
    if (!value.empty()) a.name = value;

    value = readLine("新分类路径：");
    if (!value.empty()) a.categoryPath = value;

    value = readLine("新地点：");
    if (!value.empty()) a.location = value;

    value = readLine("新日期，第几天：");
    if (!value.empty()) {
        int day = 0;
        if (parseIntStrict(value, day)) {
            a.day = day;
        } else {
            cout << "日期输入无效，保持原值。\n";
        }
    }

    value = readLine("新开始时间 HH:MM：");
    if (!value.empty()) a.startMin = parseTimeToMinutes(value);

    value = readLine("新结束时间 HH:MM：");
    if (!value.empty()) a.endMin = parseTimeToMinutes(value);

    value = readLine("新标签，用英文逗号分隔：");
    if (!value.empty()) a.tags = StringSet::fromCommaList(value);

    cout << "已修改活动。\n";
}

void recommendActivities(const DynamicList<Activity>& activities, const DynamicList<Student>& students) {
    cout << "可以输入学生编号，例如 S001；也可以直接输入兴趣标签，例如 AI,编程,竞赛。\n";
    string input = readLine("学生编号或兴趣标签：");
    StringSet interests;
    int studentIndex = findStudentIndex(students, input);
    if (studentIndex != -1) {
        interests = students[studentIndex].interests;
        cout << "学生：" << students[studentIndex].name << "，兴趣{" << interests.toString(",") << "}\n";
    } else {
        interests = StringSet::fromCommaList(input);
    }

    DynamicList<Recommendation> recommendations;
    for (int i = 0; i < activities.size(); ++i) {
        double score = interests.jaccard(activities[i].tags);
        if (score > 0.0) {
            Recommendation rec;
            rec.activity = activities[i];
            rec.score = score;
            recommendations.pushBack(rec);
        }
    }
    recommendations.sort([](const Recommendation& a, const Recommendation& b) {
        if (a.score != b.score) return a.score > b.score;
        return activityLessByTime(a.activity, b.activity);
    });

    string text = readLine("显示前多少条推荐？默认 10：");
    int limit = parseIntOrDefault(text, 10);
    cout << "\n推荐结果：\n";
    for (int i = 0; i < recommendations.size() && i < limit; ++i) {
        cout << std::fixed << std::setprecision(3) << "匹配度 " << recommendations[i].score << "  ";
        printActivityBrief(recommendations[i].activity);
    }
    if (recommendations.empty()) cout << "没有找到匹配活动。\n";
}

void checkScheduleConflicts(const DynamicList<Activity>& activities) {
    cout << "输入多个活动编号，用英文逗号分隔，例如 A0001,A0030,A0100。\n";
    DynamicList<string> ids = DataLoader::split(readLine("活动编号列表："), ',');
    DynamicList<Activity> selected;

    for (int i = 0; i < ids.size(); ++i) {
        int idx = findActivityIndex(activities, ids[i]);
        if (idx != -1) selected.pushBack(activities[idx]);
        else cout << "未找到活动：" << ids[i] << "\n";
    }

    bool hasConflict = false;
    for (int i = 0; i < selected.size(); ++i) {
        for (int j = i + 1; j < selected.size(); ++j) {
            if (selected[i].conflictsWith(selected[j])) {
                hasConflict = true;
                cout << "冲突：" << selected[i].id << " " << selected[i].name
                     << " 与 " << selected[j].id << " " << selected[j].name
                     << "，时间均为第" << selected[i].day << "天。\n";
            }
        }
    }
    if (!hasConflict) cout << "未发现时间冲突。\n";
}

void shortestPathToActivity(const DynamicList<Activity>& activities, const Graph& graph) {
    string start = readLine("当前位置：");
    string activityId = readLine("目标活动编号：");
    int idx = findActivityIndex(activities, activityId);
    if (idx == -1) {
        cout << "未找到活动。\n";
        return;
    }
    const Activity& a = activities[idx];
    cout << "目标活动：" << a.name << "，地点：" << a.location << "\n";
    PathResult result = graph.shortestPath(start, a.location);
    cout << result.toString() << "\n";
}

void categoryStatistics(const DynamicList<Activity>& activities, const CategoryTree& tree) {
    string category = readLine("请输入类别名称，例如 学术类 或 计算机：");
    cout << "分类路径：" << tree.pathToRoot(category) << "\n";
    cout << "该类别及其子类别下活动数量：" << tree.countActivities(category, activities) << "\n";
}

void bfsMap(const Graph& graph) {
    string start = readLine("BFS 起点：");
    DynamicList<string> order = graph.bfsOrder(start);
    if (order.empty()) {
        cout << "起点不存在或无法遍历。\n";
        return;
    }
    cout << "BFS 遍历顺序：";
    for (int i = 0; i < order.size(); ++i) {
        if (i > 0) cout << " -> ";
        cout << order[i];
    }
    cout << "\n";
}

void printMenu() {
    cout << "\n========== 校园活动导航与推荐系统 ==========" << "\n";
    cout << "1. 查看活动列表（按时间排序）\n";
    cout << "2. 按编号查询活动\n";
    cout << "3. 添加活动（内存中）\n";
    cout << "4. 删除活动（内存中）\n";
    cout << "5. 修改活动（内存中）\n";
    cout << "6. 根据兴趣集合推荐活动\n";
    cout << "7. 检测多个活动时间冲突\n";
    cout << "8. 查询从当前位置到活动地点的最短路径\n";
    cout << "9. 打印活动分类树\n";
    cout << "10. 统计某类别下活动数量\n";
    cout << "11. BFS 遍历校园地图\n";
    cout << "12. 打印校园地图邻接表\n";
    cout << "0. 退出\n";
}

int main(int argc, char* argv[]) {
    string dataDir = argc >= 2 ? argv[1] : "data";

    DynamicList<Activity> activities;
    DynamicList<Student> students;
    CategoryTree categoryTree;
    Graph campusMap(200);

    bool loaded =
        DataLoader::loadCategories(dataDir + "/categories.txt", categoryTree) &&
        DataLoader::loadLocations(dataDir + "/locations.txt", campusMap) &&
        DataLoader::loadRoads(dataDir + "/roads.txt", campusMap) &&
        DataLoader::loadActivities(dataDir + "/activities.txt", activities) &&
        DataLoader::loadStudents(dataDir + "/students.txt", students);
    if (!loaded) {
        cout << "数据加载失败，请检查数据目录：" << dataDir << "\n";
        return 1;
    }

    cout << "数据加载完成："
         << activities.size() << " 条活动，"
         << students.size() << " 名学生，"
         << categoryTree.size() << " 个分类结点，"
         << campusMap.vertexCount() << " 个地点，"
         << campusMap.edgeCount() << " 条道路。\n";

    while (true) {
        printMenu();
        string choice = readLine("请选择：");
        if (inputEnded || choice == "0") break;
        if (choice == "1") listActivities(activities);
        else if (choice == "2") findActivity(activities);
        else if (choice == "3") addActivity(activities);
        else if (choice == "4") deleteActivity(activities);
        else if (choice == "5") modifyActivity(activities);
        else if (choice == "6") recommendActivities(activities, students);
        else if (choice == "7") checkScheduleConflicts(activities);
        else if (choice == "8") shortestPathToActivity(activities, campusMap);
        else if (choice == "9") categoryTree.print();
        else if (choice == "10") categoryStatistics(activities, categoryTree);
        else if (choice == "11") bfsMap(campusMap);
        else if (choice == "12") campusMap.printAdjacencyMatrix();
        else cout << "无效选项。\n";
    }

    cout << "已退出。\n";
    return 0;
}
