#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import subprocess
import sys
import tempfile
from collections import deque
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Activity:
    activity_id: str
    name: str
    category_path: str
    location: str
    day: int
    start_min: int
    end_min: int
    tags: set[str]


@dataclass
class Student:
    student_id: str
    name: str
    interests: set[str]


@dataclass
class CheckResult:
    name: str
    passed: bool
    details: str
    advisory: bool = False


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compile and validate a campus activity submission against the project spec."
    )
    parser.add_argument(
        "--target",
        required=True,
        help="Submission directory that contains include/, src/, and data/.",
    )
    parser.add_argument(
        "--data-dir",
        help="Optional data directory. Defaults to <target>/data.",
    )
    parser.add_argument(
        "--strict-advisory",
        action="store_true",
        help="Treat advisory robustness checks as failures in the exit code.",
    )
    return parser.parse_args()


def trim(text: str) -> str:
    return text.strip(" \t\r\n")


def parse_time(text: str) -> int:
    hour_text, minute_text = text.split(":")
    return int(hour_text) * 60 + int(minute_text)


def minutes_to_time(minutes: int) -> str:
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def split_field(text: str, delimiter: str) -> list[str]:
    return [trim(item) for item in text.split(delimiter)]


def parse_set(text: str) -> set[str]:
    if not trim(text):
        return set()
    return {trim(item) for item in text.split(",") if trim(item)}


def load_categories(data_dir: Path) -> list[tuple[str, str]]:
    edges: list[tuple[str, str]] = []
    for line in data_dir.joinpath("categories.txt").read_text(encoding="utf-8").splitlines():
        line = trim(line)
        if not line or line.startswith("#"):
            continue
        parent, child = split_field(line, "|")[:2]
        edges.append((parent, child))
    return edges


def load_locations(data_dir: Path) -> list[str]:
    locations: list[str] = []
    for line in data_dir.joinpath("locations.txt").read_text(encoding="utf-8").splitlines():
        line = trim(line)
        if line and not line.startswith("#"):
            locations.append(line)
    return locations


def load_roads(data_dir: Path) -> list[tuple[str, str, int]]:
    roads: list[tuple[str, str, int]] = []
    for line in data_dir.joinpath("roads.txt").read_text(encoding="utf-8").splitlines():
        line = trim(line)
        if not line or line.startswith("#"):
            continue
        a, b, weight_text = split_field(line, "|")[:3]
        roads.append((a, b, int(weight_text)))
    return roads


def load_activities(data_dir: Path) -> list[Activity]:
    activities: list[Activity] = []
    for line in data_dir.joinpath("activities.txt").read_text(encoding="utf-8").splitlines():
        line = trim(line)
        if not line or line.startswith("#"):
            continue
        fields = split_field(line, "|")
        activities.append(
            Activity(
                activity_id=fields[0],
                name=fields[1],
                category_path=fields[2],
                location=fields[3],
                day=int(fields[4]),
                start_min=parse_time(fields[5]),
                end_min=parse_time(fields[6]),
                tags=parse_set(fields[7]),
            )
        )
    return activities


def load_students(data_dir: Path) -> list[Student]:
    students: list[Student] = []
    for line in data_dir.joinpath("students.txt").read_text(encoding="utf-8").splitlines():
        line = trim(line)
        if not line or line.startswith("#"):
            continue
        fields = split_field(line, "|")
        students.append(
            Student(
                student_id=fields[0],
                name=fields[1],
                interests=parse_set(fields[2]),
            )
        )
    return students


def build_category_parent(edges: list[tuple[str, str]]) -> dict[str, str | None]:
    parent: dict[str, str | None] = {}
    for p, c in edges:
        parent.setdefault(p, None)
        parent[c] = p
    return parent


def category_path_to_root(category: str, parent_map: dict[str, str | None]) -> str:
    if category not in parent_map:
        return "未找到该类别"
    path: list[str] = []
    current: str | None = category
    while current is not None:
        path.append(current)
        current = parent_map[current]
    path.reverse()
    return " -> ".join(path)


def count_category_activities(category: str, activities: list[Activity]) -> int:
    count = 0
    for activity in activities:
        parts = [trim(part) for part in activity.category_path.split("/")]
        if category in parts:
            count += 1
    return count


def activity_sort_key(activity: Activity) -> tuple[int, int, str]:
    return (activity.day, activity.start_min, activity.activity_id)


def jaccard(left: set[str], right: set[str]) -> float:
    union = left | right
    if not union:
        return 0.0
    return len(left & right) / len(union)


def recommendation_order(activities: list[Activity], interests: set[str]) -> list[tuple[float, Activity]]:
    ranked: list[tuple[float, Activity]] = []
    for activity in activities:
        score = jaccard(interests, activity.tags)
        if score > 0:
            ranked.append((score, activity))
    ranked.sort(key=lambda item: (-item[0], item[1].day, item[1].start_min, item[1].activity_id))
    return ranked


def first_conflicting_pair(activities: list[Activity]) -> tuple[Activity, Activity] | None:
    ordered = sorted(activities, key=activity_sort_key)
    for i, left in enumerate(ordered):
        for right in ordered[i + 1 :]:
            if left.day != right.day:
                if right.day > left.day:
                    break
                continue
            if not (left.end_min <= right.start_min or right.end_min <= left.start_min):
                return left, right
    return None


def build_weight_matrix(locations: list[str], roads: list[tuple[str, str, int]]) -> list[list[int]]:
    index = {name: i for i, name in enumerate(locations)}
    inf = 10**9
    weight = [[0 if i == j else inf for j in range(len(locations))] for i in range(len(locations))]
    for a, b, w in roads:
        ia = index[a]
        ib = index[b]
        if w < weight[ia][ib]:
            weight[ia][ib] = w
            weight[ib][ia] = w
    return weight


def bfs_order(locations: list[str], weight: list[list[int]], start_name: str) -> list[str]:
    inf = 10**9
    start = locations.index(start_name)
    visited = [False] * len(locations)
    queue: deque[int] = deque([start])
    visited[start] = True
    order: list[str] = []

    while queue:
        u = queue.popleft()
        order.append(locations[u])
        for v in range(len(locations)):
            if not visited[v] and weight[u][v] < inf:
                visited[v] = True
                queue.append(v)
    return order


def dijkstra(locations: list[str], weight: list[list[int]], start_name: str, end_name: str) -> tuple[bool, int, list[str]]:
    inf = 10**9
    start = locations.index(start_name)
    target = locations.index(end_name)
    visited = [False] * len(locations)
    dist = [inf] * len(locations)
    prev = [-1] * len(locations)
    dist[start] = 0

    for _ in range(len(locations)):
        best = inf
        u = -1
        for i in range(len(locations)):
            if not visited[i] and dist[i] < best:
                best = dist[i]
                u = i
        if u == -1:
            break
        visited[u] = True
        if u == target:
            break
        for v in range(len(locations)):
            if not visited[v] and weight[u][v] < inf:
                candidate = dist[u] + weight[u][v]
                if candidate < dist[v]:
                    dist[v] = candidate
                    prev[v] = u

    if dist[target] >= inf:
        return False, 0, []

    path_indices: list[int] = []
    current = target
    while current != -1:
        path_indices.append(current)
        current = prev[current]
    path_indices.reverse()
    return True, dist[target], [locations[i] for i in path_indices]


def compile_target(target: Path) -> Path:
    binary_dir = Path(tempfile.mkdtemp(prefix="campus_check_"))
    binary_path = binary_dir / "campus_app"
    cmd = [
        "g++",
        "-std=c++17",
        "-I",
        str(target / "include"),
        str(target / "src" / "main.cpp"),
        "-o",
        str(binary_path),
    ]
    completed = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
    if completed.returncode != 0:
        sys.stderr.write(completed.stdout)
        sys.stderr.write(completed.stderr)
        raise RuntimeError("编译失败")
    return binary_path


def run_program(binary: Path, data_dir: Path, input_text: str, timeout: int = 8) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [str(binary), str(data_dir)],
        input=input_text,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=timeout,
    )


def merged_output(completed: subprocess.CompletedProcess[str]) -> str:
    return completed.stdout + completed.stderr


def lines_after_marker(output: str, marker: str) -> list[str]:
    position = output.find(marker)
    if position == -1:
        return []
    tail = output[position + len(marker) :]
    lines: list[str] = []
    for raw in tail.splitlines():
        if raw.startswith("========== 校园活动导航与推荐系统 =========="):
            break
        if trim(raw):
            lines.append(raw)
    return lines


def extract_activity_ids(lines: list[str]) -> list[str]:
    ids: list[str] = []
    for raw in lines:
        match = re.search(r"\b([A-Z]\d{4})\b", raw)
        if match:
            ids.append(match.group(1))
    return ids


def make_result(name: str, passed: bool, details: str, advisory: bool = False) -> CheckResult:
    return CheckResult(name=name, passed=passed, details=details, advisory=advisory)


def required_checks(binary: Path, data_dir: Path) -> list[CheckResult]:
    activities = load_activities(data_dir)
    students = load_students(data_dir)
    categories = load_categories(data_dir)
    locations = load_locations(data_dir)
    roads = load_roads(data_dir)
    parent_map = build_category_parent(categories)
    weight = build_weight_matrix(locations, roads)
    results: list[CheckResult] = []

    # 1. Load counts
    expected_counts = (
        len(activities),
        len(students),
        len(parent_map),
        len(locations),
        len(roads),
    )
    completed = run_program(binary, data_dir, "0\n")
    output = merged_output(completed)
    match = re.search(
        r"数据加载完成：(\d+) 条活动，(\d+) 名学生，(\d+) 个分类结点，(\d+) 个地点，(\d+) 条道路。",
        output,
    )
    if not match:
        results.append(make_result("加载统计", False, "未找到数据加载统计行"))
    else:
        actual_counts = tuple(int(value) for value in match.groups())
        passed = actual_counts == expected_counts
        results.append(
            make_result(
                "加载统计",
                passed,
                f"期望 {expected_counts}，实际 {actual_counts}",
            )
        )

    # 2. Sorted activity list
    expected_sorted = [activity.activity_id for activity in sorted(activities, key=activity_sort_key)[:3]]
    completed = run_program(binary, data_dir, "1\n3\n0\n")
    output = merged_output(completed)
    lines = lines_after_marker(output, "按时间排序后的活动：")
    actual_sorted = extract_activity_ids(lines)[:3]
    results.append(
        make_result(
            "活动排序",
            actual_sorted == expected_sorted,
            f"期望前 3 条 {expected_sorted}，实际 {actual_sorted}",
        )
    )

    # 3. Query by activity id
    sample = activities[0]
    completed = run_program(binary, data_dir, f"2\n{sample.activity_id}\n0\n")
    output = merged_output(completed)
    passed = (
        f"活动编号：{sample.activity_id}" in output
        and f"活动名称：{sample.name}" in output
        and f"活动地点：{sample.location}" in output
        and f"活动时间：第{sample.day}天 {minutes_to_time(sample.start_min)}-{minutes_to_time(sample.end_min)}" in output
    )
    results.append(
        make_result(
            "活动查询",
            passed,
            f"检查活动 {sample.activity_id} 的名称、地点和时间是否正确输出",
        )
    )

    # 4. Add / modify / delete
    existing_ids = {activity.activity_id for activity in activities}
    synthetic_id = "T9000"
    while synthetic_id in existing_ids:
        number = int(synthetic_id[1:]) + 1
        synthetic_id = f"T{number:04d}"

    add_name = "自动化测试活动"
    updated_name = "自动化测试活动-已修改"
    add_script = "\n".join(
        [
            "3",
            synthetic_id,
            add_name,
            "校园活动/学术类/计算机",
            locations[0],
            "3",
            "09:00",
            "10:00",
            "AI,测试",
            "2",
            synthetic_id,
            "5",
            synthetic_id,
            updated_name,
            "",
            "",
            "",
            "",
            "",
            "",
            "2",
            synthetic_id,
            "4",
            synthetic_id,
            "2",
            synthetic_id,
            "0",
            "",
        ]
    )
    completed = run_program(binary, data_dir, add_script)
    output = merged_output(completed)
    passed = (
        "已添加活动。" in output
        and f"活动名称：{add_name}" in output
        and "已修改活动。" in output
        and f"活动名称：{updated_name}" in output
        and f"已删除活动：{synthetic_id}" in output
        and f"未找到活动：{synthetic_id}" in output
    )
    results.append(
        make_result(
            "增删改查联动",
            passed,
            f"检查新增 {synthetic_id}、修改后查询、删除后查询",
        )
    )

    # 5. Recommendation
    recommendation_case: tuple[Student, list[str]] | None = None
    for student in students:
        top_ids = [item[1].activity_id for item in recommendation_order(activities, student.interests)[:3]]
        if len(top_ids) >= 3:
            recommendation_case = (student, top_ids)
            break
    if recommendation_case is None:
        results.append(make_result("兴趣推荐", False, "数据中未找到可用于推荐测试的学生"))
    else:
        student, expected_ids = recommendation_case
        completed = run_program(binary, data_dir, f"6\n{student.student_id}\n3\n0\n")
        output = merged_output(completed)
        lines = lines_after_marker(output, "推荐结果：")
        actual_ids = extract_activity_ids(lines)[:3]
        passed = (
            f"学生：{student.name}" in output
            and actual_ids == expected_ids
            and "匹配度" in output
        )
        results.append(
            make_result(
                "兴趣推荐",
                passed,
                f"期望前 3 条 {expected_ids}，实际 {actual_ids}",
            )
        )

    # 6. Schedule conflict
    pair = first_conflicting_pair(activities)
    if pair is None:
        results.append(make_result("时间冲突", False, "数据中未找到冲突活动对"))
    else:
        left, right = pair
        completed = run_program(binary, data_dir, f"7\n{left.activity_id},{right.activity_id}\n0\n")
        output = merged_output(completed)
        passed = left.activity_id in output and right.activity_id in output and "冲突：" in output
        results.append(
            make_result(
                "时间冲突",
                passed,
                f"检查 {left.activity_id} 与 {right.activity_id} 是否识别为冲突",
            )
        )

    # 7. Shortest path
    start = locations[0]
    target_activity = activities[0]
    reachable, distance, path = dijkstra(locations, weight, start, target_activity.location)
    completed = run_program(binary, data_dir, f"8\n{start}\n{target_activity.activity_id}\n0\n")
    output = merged_output(completed)
    expected_path_text = " -> ".join(path)
    passed = (
        reachable
        and f"目标活动：{target_activity.name}，地点：{target_activity.location}" in output
        and f"距离/时间：{distance} 分钟，路径：{expected_path_text}" in output
    )
    results.append(
        make_result(
            "最短路径",
            passed,
            f"期望路径 {expected_path_text}，距离 {distance}",
        )
    )

    # 8. Category statistics
    category = next(child for _, child in categories if count_category_activities(child, activities) > 0)
    expected_path = category_path_to_root(category, parent_map)
    expected_count = count_category_activities(category, activities)
    completed = run_program(binary, data_dir, f"10\n{category}\n0\n")
    output = merged_output(completed)
    passed = (
        f"分类路径：{expected_path}" in output
        and f"该类别及其子类别下活动数量：{expected_count}" in output
    )
    results.append(
        make_result(
            "分类统计",
            passed,
            f"期望路径 {expected_path}，数量 {expected_count}",
        )
    )

    # 9. BFS traversal
    expected_bfs = bfs_order(locations, weight, start)
    completed = run_program(binary, data_dir, f"11\n{start}\n0\n")
    output = merged_output(completed)
    expected_bfs_text = " -> ".join(expected_bfs)
    passed = f"BFS 遍历顺序：{expected_bfs_text}" in output
    results.append(
        make_result(
            "BFS 遍历",
            passed,
            f"期望顺序长度 {len(expected_bfs)}，起点 {start}",
        )
    )

    # 10. Category tree printing
    completed = run_program(binary, data_dir, "9\n0\n")
    output = merged_output(completed)
    root, child = categories[0]
    passed = root in output and child in output
    results.append(
        make_result(
            "分类树打印",
            passed,
            f"检查输出中包含根结点 {root} 和子结点 {child}",
        )
    )

    return results


def advisory_checks(binary: Path, data_dir: Path) -> list[CheckResult]:
    results: list[CheckResult] = []

    # Invalid numeric input should not crash, but reference solution currently does.
    completed = run_program(binary, data_dir, "1\nabc\n", timeout=4)
    output = merged_output(completed)
    passed = completed.returncode == 0 and "invalid_argument" not in output and "terminate called" not in output
    results.append(
        make_result(
            "提醒项：非法数字输入健壮性",
            passed,
            "向“显示前多少条活动”输入 abc，程序不应崩溃",
            advisory=True,
        )
    )

    # Missing data directory should ideally stop early instead of entering the menu.
    missing_dir = data_dir.parent / "__missing_data_for_check__"
    completed = subprocess.run(
        [str(binary), str(missing_dir)],
        input="0\n",
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=4,
    )
    output = merged_output(completed)
    passed = "请选择：" not in output
    results.append(
        make_result(
            "提醒项：缺失数据目录处理",
            passed,
            "数据目录不存在时，理想行为是报错后直接退出",
            advisory=True,
        )
    )

    return results


def print_results(results: list[CheckResult]) -> None:
    for result in results:
        prefix = "[PASS]" if result.passed else "[FAIL]"
        if result.advisory and not result.passed:
            prefix = "[WARN]"
        print(f"{prefix} {result.name}: {result.details}")


def main() -> int:
    args = parse_args()
    target = Path(args.target).resolve()
    data_dir = Path(args.data_dir).resolve() if args.data_dir else target / "data"

    required_paths = [target / "include", target / "src" / "main.cpp", data_dir]
    for path in required_paths:
        if not path.exists():
            print(f"[ERROR] 缺少必要路径：{path}", file=sys.stderr)
            return 2

    try:
        binary = compile_target(target)
    except RuntimeError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return 2

    required = required_checks(binary, data_dir)
    advisory = advisory_checks(binary, data_dir)

    print("== 必测项 ==")
    print_results(required)
    print("\n== 提醒项 ==")
    print_results(advisory)

    required_failed = any(not result.passed for result in required)
    advisory_failed = any(not result.passed for result in advisory)

    if required_failed:
        return 1
    if advisory_failed and args.strict_advisory:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
