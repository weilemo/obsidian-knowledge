from pathlib import Path
import json


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "ui" / "data.js"


def read_lines(name):
    path = DATA / name
    return [
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.startswith("#")
    ]


def parse_time(text):
    hour, minute = text.split(":")
    return int(hour) * 60 + int(minute)


def load_activities():
    activities = []
    for line in read_lines("activities.txt"):
        fields = line.split("|")
        if len(fields) < 8:
            continue
        tags = [item.strip() for item in fields[7].split(",") if item.strip()]
        category_parts = [item.strip() for item in fields[2].split("/") if item.strip()]
        activities.append(
            {
                "id": fields[0],
                "name": fields[1],
                "categoryPath": fields[2],
                "categoryParts": category_parts,
                "primaryCategory": category_parts[1] if len(category_parts) > 1 else fields[2],
                "leafCategory": category_parts[-1] if category_parts else fields[2],
                "location": fields[3],
                "day": int(fields[4]),
                "start": fields[5],
                "end": fields[6],
                "startMin": parse_time(fields[5]),
                "endMin": parse_time(fields[6]),
                "tags": tags,
            }
        )
    return activities


def load_students():
    students = []
    for line in read_lines("students.txt"):
        fields = line.split("|")
        if len(fields) < 3:
            continue
        students.append(
            {
                "id": fields[0],
                "name": fields[1],
                "interests": [item.strip() for item in fields[2].split(",") if item.strip()],
            }
        )
    return students


def load_locations():
    return read_lines("locations.txt")


def load_roads():
    roads = []
    for line in read_lines("roads.txt"):
        fields = line.split("|")
        if len(fields) >= 3:
            roads.append({"a": fields[0], "b": fields[1], "weight": int(fields[2])})
    return roads


def load_categories():
    edges = []
    for line in read_lines("categories.txt"):
        fields = line.split("|")
        if len(fields) >= 2:
            edges.append({"parent": fields[0], "child": fields[1]})
    return edges


def main():
    OUT.parent.mkdir(exist_ok=True)
    payload = {
        "activities": load_activities(),
        "students": load_students(),
        "locations": load_locations(),
        "roads": load_roads(),
        "categories": load_categories(),
    }
    OUT.write_text(
        "window.CAMPUS_DATA = "
        + json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        + ";\n",
        encoding="utf-8",
    )
    print(f"wrote {OUT} ({OUT.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
