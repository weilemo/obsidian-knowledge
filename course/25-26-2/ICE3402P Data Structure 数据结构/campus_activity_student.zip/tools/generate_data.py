# -*- coding: utf-8 -*-
"""
Generate reproducible test data for the Campus Activity Navigation & Recommendation project.
The generated files use UTF-8 and pipe-separated fields.
"""
from pathlib import Path
import random

random.seed(20260427)

BASE = Path(__file__).resolve().parent.parent
OUTS = [BASE / "complete" / "data", BASE / "starter" / "data"]
for out in OUTS:
    out.mkdir(parents=True, exist_ok=True)

locations = [
    "北区宿舍", "南区宿舍", "东区宿舍", "西区宿舍", "第一教学楼", "第二教学楼", "第三教学楼",
    "图书馆", "计算机楼", "实验中心", "数学楼", "物理楼", "外语楼", "经济管理楼",
    "大学生活动中心", "体育馆", "篮球场", "足球场", "游泳馆", "食堂一", "食堂二", "校医院",
    "行政楼", "报告厅A", "报告厅B", "艺术中心", "音乐厅", "创新创业中心", "志愿服务中心",
    "心理咨询中心", "校门", "湖心广场"
]

category_tree = {
    "校园活动": ["学术类", "体育类", "文艺类", "社团类", "职业发展类", "校园生活类"],
    "学术类": ["计算机", "数学", "物理", "生物", "经济", "外语"],
    "体育类": ["球类", "跑步", "健身", "游泳", "武术"],
    "文艺类": ["音乐", "绘画", "戏剧", "舞蹈", "文学"],
    "社团类": ["科技社团", "公益社团", "摄影社团", "辩论社团", "创业社团"],
    "职业发展类": ["实习", "面试", "简历", "企业参访"],
    "校园生活类": ["宿舍", "饮食", "心理健康", "安全教育", "学习方法"],
}

leaf_to_parent = {}
for p, children in category_tree.items():
    for c in children:
        if c not in category_tree:
            leaf_to_parent[c] = p

leaf_tags = {
    "计算机": ["AI", "编程", "算法", "数据结构", "科研"],
    "数学": ["数学", "建模", "竞赛", "逻辑", "统计"],
    "物理": ["物理", "实验", "量子", "科普", "科研"],
    "生物": ["生物", "生命科学", "实验", "科普", "健康"],
    "经济": ["经济", "金融", "数据分析", "商业", "投资"],
    "外语": ["英语", "口语", "翻译", "文化", "交流"],
    "球类": ["篮球", "足球", "羽毛球", "乒乓球", "运动"],
    "跑步": ["跑步", "晨跑", "耐力", "运动", "健康"],
    "健身": ["健身", "力量", "体能", "运动", "健康"],
    "游泳": ["游泳", "体能", "水上运动", "健康", "比赛"],
    "武术": ["武术", "太极", "防身", "传统文化", "运动"],
    "音乐": ["音乐", "乐队", "合唱", "钢琴", "表演"],
    "绘画": ["绘画", "设计", "美术", "创作", "展览"],
    "戏剧": ["戏剧", "表演", "剧本", "舞台", "创作"],
    "舞蹈": ["舞蹈", "街舞", "民族舞", "表演", "训练"],
    "文学": ["文学", "写作", "阅读", "诗歌", "分享"],
    "科技社团": ["机器人", "开源", "编程", "硬件", "创新"],
    "公益社团": ["公益", "志愿", "服务", "环保", "社区"],
    "摄影社团": ["摄影", "后期", "影像", "展览", "创作"],
    "辩论社团": ["辩论", "演讲", "逻辑", "表达", "比赛"],
    "创业社团": ["创业", "商业计划", "路演", "创新", "团队"],
    "实习": ["实习", "求职", "企业", "职业规划", "经验"],
    "面试": ["面试", "表达", "求职", "模拟", "沟通"],
    "简历": ["简历", "求职", "职业规划", "写作", "优化"],
    "企业参访": ["企业", "参访", "产业", "交流", "职业规划"],
    "宿舍": ["宿舍", "生活", "整理", "沟通", "安全"],
    "饮食": ["饮食", "健康", "美食", "营养", "生活"],
    "心理健康": ["心理", "压力", "情绪", "健康", "沟通"],
    "安全教育": ["安全", "消防", "急救", "防诈骗", "生活"],
    "学习方法": ["学习", "时间管理", "笔记", "效率", "考试"],
}

loc_by_parent = {
    "学术类": ["图书馆", "计算机楼", "实验中心", "数学楼", "物理楼", "报告厅A", "报告厅B"],
    "体育类": ["体育馆", "篮球场", "足球场", "游泳馆", "湖心广场"],
    "文艺类": ["艺术中心", "音乐厅", "大学生活动中心", "报告厅B"],
    "社团类": ["大学生活动中心", "创新创业中心", "志愿服务中心", "湖心广场"],
    "职业发展类": ["创新创业中心", "报告厅A", "报告厅B", "经济管理楼"],
    "校园生活类": ["心理咨询中心", "校医院", "食堂一", "食堂二", "大学生活动中心", "北区宿舍", "南区宿舍"],
}

templates = {
    "学术类": ["{leaf}专题讲座", "{leaf}实践工作坊", "{leaf}前沿分享会", "{leaf}竞赛训练营", "{leaf}读书讨论班"],
    "体育类": ["{leaf}友谊赛", "{leaf}训练营", "{leaf}体验课", "{leaf}挑战赛", "{leaf}健康打卡"],
    "文艺类": ["{leaf}创作沙龙", "{leaf}表演排练", "{leaf}作品展", "{leaf}分享夜", "{leaf}入门课"],
    "社团类": ["{leaf}招新说明会", "{leaf}项目路演", "{leaf}开放日", "{leaf}实践活动", "{leaf}成员培训"],
    "职业发展类": ["{leaf}指导课", "{leaf}经验分享", "{leaf}模拟训练", "{leaf}专题讲座", "{leaf}咨询日"],
    "校园生活类": ["{leaf}主题班会", "{leaf}知识讲堂", "{leaf}体验活动", "{leaf}互助小组", "{leaf}技能训练"],
}

# Write categories
cat_lines = []
for parent, children in category_tree.items():
    for child in children:
        cat_lines.append(f"{parent}|{child}\n")

# Write locations
loc_lines = [x + "\n" for x in locations]

# Build connected road network: first a chain, then many extra roads.
edges = {}
def add_edge(a, b, w):
    if a == b:
        return
    key = tuple(sorted((a, b)))
    if key not in edges:
        edges[key] = w

for i in range(len(locations) - 1):
    add_edge(locations[i], locations[i+1], random.randint(3, 12))
# A few intentional shortcuts
shortcuts = [
    ("北区宿舍", "第一教学楼", 6), ("南区宿舍", "体育馆", 7), ("东区宿舍", "图书馆", 8),
    ("西区宿舍", "食堂二", 5), ("校门", "湖心广场", 4), ("湖心广场", "图书馆", 5),
    ("大学生活动中心", "艺术中心", 4), ("创新创业中心", "经济管理楼", 5),
    ("计算机楼", "实验中心", 3), ("第一教学楼", "第二教学楼", 4),
]
for a, b, w in shortcuts:
    add_edge(a, b, w)
while len(edges) < 96:
    a, b = random.sample(locations, 2)
    add_edge(a, b, random.randint(2, 16))
road_lines = [f"{a}|{b}|{w}\n" for (a, b), w in sorted(edges.items())]

# Activities
all_leafs = list(leaf_to_parent.keys())
activity_lines = []
for i in range(1, 401):
    leaf = random.choice(all_leafs)
    parent = leaf_to_parent[leaf]
    path = f"校园活动/{parent}/{leaf}"
    location = random.choice(loc_by_parent[parent])
    day = random.randint(1, 30)
    start_hour = random.randint(8, 19)
    start_minute = random.choice([0, 15, 30, 45])
    duration = random.choice([60, 75, 90, 105, 120, 150, 180])
    start_total = start_hour * 60 + start_minute
    end_total = min(start_total + duration, 22 * 60)
    name = random.choice(templates[parent]).format(leaf=leaf)
    if random.random() < 0.35:
        name += f" 第{random.randint(1, 6)}期"
    tags = set(random.sample(leaf_tags[leaf], min(3, len(leaf_tags[leaf]))))
    tags.add(parent.replace("类", ""))
    # add one noisy common tag sometimes
    if random.random() < 0.55:
        tags.add(random.choice(["交友", "讲座", "实践", "比赛", "入门", "进阶", "团队", "校园"] ))
    tag_text = ",".join(sorted(tags))
    activity_lines.append(
        f"A{i:04d}|{name}|{path}|{location}|{day}|{start_total//60:02d}:{start_total%60:02d}|{end_total//60:02d}:{end_total%60:02d}|{tag_text}\n"
    )

# Students
all_tags = sorted({tag for tags in leaf_tags.values() for tag in tags} | {"交友", "讲座", "实践", "比赛", "入门", "进阶", "团队", "校园"})
student_lines = []
for i in range(1, 121):
    tags = sorted(random.sample(all_tags, random.randint(5, 9)))
    student_lines.append(f"S{i:03d}|学生{i:03d}|{','.join(tags)}\n")

for out in OUTS:
    (out / "categories.txt").write_text("".join(cat_lines), encoding="utf-8")
    (out / "locations.txt").write_text("".join(loc_lines), encoding="utf-8")
    (out / "roads.txt").write_text("".join(road_lines), encoding="utf-8")
    (out / "activities.txt").write_text("".join(activity_lines), encoding="utf-8")
    (out / "students.txt").write_text("".join(student_lines), encoding="utf-8")

print("Generated:")
print(f"  categories: {len(cat_lines)}")
print(f"  locations : {len(loc_lines)}")
print(f"  roads     : {len(road_lines)}")
print(f"  activities: {len(activity_lines)}")
print(f"  students  : {len(student_lines)}")
